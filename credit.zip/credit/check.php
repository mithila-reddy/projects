<?php
include 'conn.php';
$sender = $_POST['sender'];
$ncredits = $_POST['credits'];
$receiver = $_POST['receiver'];
$get1=mysqli_query($conn,"SELECT current_credits FROM user where name='".$sender."'");
$row1 = mysqli_fetch_assoc($get1);
$sender_credits = $row1['current_credits'];
$get2=mysqli_query($conn,"SELECT current_credits FROM user where name='".$receiver."'");
$row2 = mysqli_fetch_assoc($get1);
$receiver_credits = $row2['current_credits'];


if(isset($_POST['transfer']))
{

	if(empty($receiver) || empty($ncredits) || empty($sender) )
	{
		echo "<script>alert(\"PLEASE FILL ALL THE DETAILS PROPERLY\");window.location=\"credit_transfer.php\";</script>";
	}
	else{
		if($sender_credits>=$ncredits){
			$sender_credits = $sender_credits-$ncredits;
			
			$one=mysqli_query($conn,"UPDATE user set current_credits='".$sender_credits."' where name='".$sender."'");
			
			echo "<script>alert(\"CREDITS TO TRANSFERED successfully\");window.location=\"credit_transfer.php\";</script>";
		}
		else
		{
			echo "<script>alert(\"Sorry, INSUFFICIANT CREDITS TO TRANSFERED PROPERLY\");window.location=\"credit_transfer.php\";</script>";
		}
	}
}
?>