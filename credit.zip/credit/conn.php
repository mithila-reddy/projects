<?php
$server="localhost";
$uid="root";
$pwd="";
$dbms="creditdb";
$conn=mysqli_connect($server,$uid,$pwd,$dbms);
?>