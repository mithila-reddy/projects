<?php
include 'conn.php';
$get=mysqli_query($conn,'SELECT name FROM user');
$option = '';
 while($row = mysqli_fetch_assoc($get))
{
  $option .= '<option value = "'.$row['name'].'">'.$row['name'].'</option>';
}
?>
<html>
<head>
	<title>transfer page</title>
</head>
<style type="text/css">
	table
	{
	  border-collapse: collapse;
	}

	table, th, td {
	  border: 1px solid black;
	}
	td{
		padding: 10px;
		width: 150px;
	}
	select, input{
		width: 180px
	}
</style>
<body>
	<div style="margin:10%; border: 1px; border-radius: 5px; padding: 5%; text-align: center; border-style: solid;">
		<form action="check.php" method="POST">
			<table align="center">
				<tr>
					<td>Sender :</td>
					<td>
						<select name="sender">
							<?php 
							echo $option; 
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Credits :</td>
					<td><input type="number" name="credits"></td>
				</tr>
				<tr>
					<td>Receiver :</td>
					<td>											
						<select name="receiver"> 
							<?php 
							echo $option; 
							?>
						</select>
					</td>
				</tr>
			</table><br><br>
<input type="submit" value="transfer" class="style" name="transfer">
</form>
</body>
</html>