<?php
include 'conn.php';
$get=mysqli_query($conn,'SELECT * FROM user');
$option = '';
 while($row = mysqli_fetch_assoc($get))
{
  $option .= '<tr>';
  $option .= '<td>'.$row['name'].'</td>';
  $option .= '<td>'.$row['age'].'</td>';
  $option .= '<td>'.$row['email'].'</td>';
  $option .= '<td>'.$row['current_credits'].'</td>';
  $option .= '</tr>';
}
?>
<html>

<head>
	<title>User details page</title>
</head>
<style type="text/css">
	table
	{
	  border-collapse: collapse;
	}

	table, th, td {
	  border: 1px solid black;
	}
	td{
		padding: 10px;
		width: 150px;
	}
	select, input{
		width: 180px
	}
</style>
<body>
	<div style="margin:10%; border: 1px; border-radius: 5px; padding: 5%; text-align: center; border-style: solid;">
		<table align="center">
			<?php echo $option; ?>
		</table>
</body>
</html>
